export const BASE_URL = "http://localhost/WEB-XPEED-BE";
