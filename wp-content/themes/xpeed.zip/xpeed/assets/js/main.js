import "./common.js";
import "./pages/home.js";
import "./pages/auth.js";
import "./pages/product.js";
import "./pages/cart.js";
import "./pages/payment.js";
