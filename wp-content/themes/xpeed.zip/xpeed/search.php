<?php

/**
 * The template for displaying search results pages
 *
 */

get_header();
?>

<?php
get_footer();
