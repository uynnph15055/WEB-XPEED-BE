<?php
/**
 * The template for displaying 404 pages (not found)
 *
 */

get_header(); ?>


<?php get_footer();