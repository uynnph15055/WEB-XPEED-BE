<?php

/**
 * The template for displaying archive pages
 *
 */

get_header();
?>
<h1>Nguyễn nGọ ciUY</h1>
<?php
get_footer();
