<?php

if ( ! defined( 'ABSPATH' ) ) {
    die( 'Invalid request.' );
}

class jobSync{
    public function __construct()
    {
    }
}

new jobSync();
