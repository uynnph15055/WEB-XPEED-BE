<?php

if (!defined('ABSPATH')) {
    die('Invalid request.');
}

class API {
    public function __construct()
    {
    }
}
new API();